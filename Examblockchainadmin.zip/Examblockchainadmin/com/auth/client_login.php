<?php session_start();?>
<html>
<body>
<?php

// $servername = "localhost";
// $username = "root";
// $password = "atoconn";
// $dbname = "avm";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blockchain_admin";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // echo $_SERVER["DOCUMENT_ROOT"]; // /home1/demonuts/public_html
    // including the database connection file
    // include_once ("config.php");

    $userid = $_POST['username'];
    $password = $_POST['password'];    
    $purl = $_POST['purl'];
    if(strlen($purl) <2){
        $purl="../../examadmin.php";
    }
    if ($userid == '' || $password == '') {
        echo array(
            "status" => "false",
            "message" => "Parameter missing!"
        );
    } else {
        $query = "SELECT * FROM login WHERE userid='" . $userid . "' AND password='" . $password . "'";
        $result = mysqli_query($conn, $query);

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $_SESSION["userid"]=$userid;
//                 echo "success";
                if ($purl == "") {
                    header("Location:dashboard.php");
                } else {
                    echo $purl;
                    header("Location:" . $purl);
                }
            }
        } else {
            echo "Invalid email or Password";
        }
        $conn->close();
    }
}
?>
</body>
</html>