
<?php

class Connection{
    public function getConnection(){
        $host = "localhost";
        $user = "root";
        $password = "";
        $db = "blockchain_admin";
        
        $conn = mysqli_connect ( $host, $user, $password, $db );
        
        // Check connection
        if (mysqli_connect_errno ()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error ();
        }
        return $conn;
    }
}


?>