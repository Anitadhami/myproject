<?php

/**
 * @author ATOCONN
 *
 */
class Node{
	
	private $id;
	
	private $node_id;
	
	private $node_name;
	
	private $node_ip_address;
	
	private $status;
	
	private $created_by;
	
	private $created_date;
	
	private $block;
	
	
	
	/**
     * @return mixed
     */
    public function getBlock()
    {
        return $this->block;
    }

    /**
     * @param mixed $block
     */
    public function setBlock($block)
    {
        $this->block = $block;
    }

    /**
	 * @return mixed
	 */
	public function getId()
	{
		return $this->id;
	}
	
	/**
	 * @return mixed
	 */
	public function getNode_id()
	{
		return $this->node_id;
	}
	
	/**
	 * @return mixed
	 */
	public function getNode_name()
	{
		return $this->node_name;
	}
	
	/**
	 * @return mixed
	 */
	public function getNode_ip_address()
	{
		return $this->node_ip_address;
	}
	
	/**
	 * @return mixed
	 */
	public function getStatus()
	{
		return $this->status;
	}
	
	/**
	 * @return mixed
	 */
	public function getCreated_by()
	{
		return $this->created_by;
	}
	
	/**
	 * @return mixed
	 */
	public function getCreated_date()
	{
		return $this->created_date;
	}
	
	/**
	 * @return mixed
	 */
	public function setId($id)
	{
		$this->id = $id;
	}
	
	
	public function setNode_id($node_id)
	{
		$this->node_id = $node_id;
	}
	
	public function setNode_name($node_name)
	{
		$this->node_name = $node_name;
	}
	
	
	public function setNode_ip_address($node_ip_address)
	{
		$this->node_ip_address = $node_ip_address;
	}
	
	
	public function setStatus($status)
	{
		$this->status = $status;
	}
	
	
	
	public function setCreated_by($created_by)
	{
		$this->created_by = $created_by;
	}
	
	
	public function setCreated_date($created_date)
	{
		$this->created_date = $created_date;
	}
	
	
	
}