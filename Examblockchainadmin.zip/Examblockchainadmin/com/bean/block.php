<?php
class block{
    private $id;
    private $block_id;
    private $hash_of_blockid;
    private $id_of_previousblock;
    private $hash_of_previousblock;
    private $encrypted_data;
    private $decrypted_data;
    private $hash_of_data;
    private $related_node ;
    private $related_db;
    private $related_id;
    /**
     * @return mixed
     */
    public function getDecrypted_data()
    {
        return $this->decrypted_data;
    }

    /**
     * @param mixed $decrypted_data
     */
    public function setDecrypted_data($decrypted_data)
    {
        $this->decrypted_data = $decrypted_data;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getBlock_id()
    {
        return $this->block_id;
    }

    /**
     * @return mixed
     */
    public function getHash_of_blockid()
    {
        return $this->hash_of_blockid;
    }

    /**
     * @return mixed
     */
    public function getId_of_previousblock()
    {
        return $this->id_of_previousblock;
    }

    /**
     * @return mixed
     */
    public function getHash_of_previousblock()
    {
        return $this->hash_of_previousblock;
    }

    /**
     * @return mixed
     */
    public function getEncrypted_data()
    {
        return $this->encrypted_data;
    }

    /**
     * @return mixed
     */
    public function getHash_of_data()
    {
        return $this->hash_of_data;
    }

    /**
     * @return mixed
     */
    public function getRelated_node()
    {
        return $this->related_node;
    }

    /**
     * @return mixed
     */
    public function getRelated_db()
    {
        return $this->related_db;
    }

    /**
     * @return mixed
     */
    public function getRelated_id()
    {
        return $this->related_id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $block_id
     */
    public function setBlock_id($block_id)
    {
        $this->block_id = $block_id;
    }

    /**
     * @param mixed $hash_of_blockid
     */
    public function setHash_of_blockid($hash_of_blockid)
    {
        $this->hash_of_blockid = $hash_of_blockid;
    }

    /**
     * @param mixed $id_of_previousblock
     */
    public function setId_of_previousblock($id_of_previousblock)
    {
        $this->id_of_previousblock = $id_of_previousblock;
    }

    /**
     * @param mixed $hash_of_previousblock
     */
    public function setHash_of_previousblock($hash_of_previousblock)
    {
        $this->hash_of_previousblock = $hash_of_previousblock;
    }

    /**
     * @param mixed $encrypted_data
     */
    public function setEncrypted_data($encrypted_data)
    {
        $this->encrypted_data = $encrypted_data;
    }

    /**
     * @param mixed $hash_of_data
     */
    public function setHash_of_data($hash_of_data)
    {
        $this->hash_of_data = $hash_of_data;
    }

    /**
     * @param mixed $related_node
     */
    public function setRelated_node($related_node)
    {
        $this->related_node = $related_node;
    }

    /**
     * @param mixed $related_db
     */
    public function setRelated_db($related_db)
    {
        $this->related_db = $related_db;
    }

    /**
     * @param mixed $related_id
     */
    public function setRelated_id($related_id)
    {
        $this->related_id = $related_id;
    }

    
    
}