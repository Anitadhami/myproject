<?php
class Certificate{
    private $id;
    private $certificate_id;
    private $student_id;
    private $node_id;
    private $title;
    private $url;
    private $created_by;
    private $created_date;
    /**
     * @return mixed
     */
    public function getNode_id()
    {
        return $this->node_id;
    }

    /**
     * @param mixed $node_id
     */
    public function setNode_id($node_id)
    {
        $this->node_id = $node_id;
    }

    /**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * @param mixed $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getCertificate_id()
    {
        return $this->certificate_id;
    }

    /**
     * @return mixed
     */
    public function getStudent_id()
    {
        return $this->student_id;
    }

    /**
     * @return mixed
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * @return mixed
     */
    public function getCreated_by()
    {
        return $this->created_by;
    }

    /**
     * @return mixed
     */
    public function getCreated_date()
    {
        return $this->created_date;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $certificate_id
     */
    public function setCertificate_id($certificate_id)
    {
        $this->certificate_id = $certificate_id;
    }

    /**
     * @param mixed $student_id
     */
    public function setStudent_id($student_id)
    {
        $this->student_id = $student_id;
    }

    /**
     * @param mixed $url
     */
    public function setUrl($url)
    {
        $this->url = $url;
    }

    /**
     * @param mixed $created_by
     */
    public function setCreated_by($created_by)
    {
        $this->created_by = $created_by;
    }

    /**
     * @param mixed $created_date
     */
    public function setCreated_date($created_date)
    {
        $this->created_date = $created_date;
    }

}