<?php

class distribute{
    
    private $id;
    private $did;
    private $exam_id;
    private $subject_id;
    private $node_id;
    private $created_by;
    private $created_date;
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }
    
    /**
     * @return mixed
     */
    public function getDid()
    {
        return $this->did;
    }
    
    /**
     * @return mixed
     */
    public function getExam_id()
    {
        return $this->exam_id;
    }
    
    /**
     * @return mixed
     */
    public function getSubject_id()
    {
        return $this->subject_id;
    }
    
    /**
     * @return mixed
     */
    public function getNode_id()
    {
        return $this->node_id;
    }
    
    /**
     * @return mixed
     */
    public function getCreated_by()
    {
        return $this->created_by;
    }
    
    /**
     * @return mixed
     */
    public function getCreated_date()
    {
        return $this->created_date;
    }
    
    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }
    
    /**
     * @param mixed $did
     */
    public function setDid($did)
    {
        $this->did = $did;
    }
    
    /**
     * @param mixed $exam_id
     */
    public function setExam_id($exam_id)
    {
        $this->exam_id = $exam_id;
    }
    
    /**
     * @param mixed $subject_id
     */
    public function setSubject_id($subject_id)
    {
        $this->subject_id = $subject_id;
    }
    
    /**
     * @param mixed $node_id
     */
    public function setNode_id($node_id)
    {
        $this->node_id = $node_id;
    }
    
    /**
     * @param mixed $created_by
     */
    public function setCreated_by($created_by)
    {
        $this->created_by = $created_by;
    }
    
    /**
     * @param mixed $created_date
     */
    public function setCreated_date($created_date)
    {
        $this->created_date = $created_date;
    }
    
    
    
}

