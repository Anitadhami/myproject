<?php
class examadmin{
    private $id;
    private $exam_id;
    private $exam_name;
    private $type;
    private $created_by;
    private $created_date;
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getExam_id()
    {
        return $this->exam_id;
    }

    /**
     * @return mixed
     */
    public function getExam_name()
    {
        return $this->exam_name;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @return mixed
     */
    public function getCreated_by()
    {
        return $this->created_by;
    }

    /**
     * @return mixed
     */
    public function getCreated_date()
    {
        return $this->created_date;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $exam_id
     */
    public function setExam_id($exam_id)
    {
        $this->exam_id = $exam_id;
    }

    /**
     * @param mixed $exam_name
     */
    public function setExam_name($exam_name)
    {
        $this->exam_name = $exam_name;
    }

    /**
     * @param mixed $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }

    /**
     * @param mixed $created_by
     */
    public function setCreated_by($created_by)
    {
        $this->created_by = $created_by;
    }

    /**
     * @param mixed $created_date
     */
    public function setCreated_date($created_date)
    {
        $this->created_date = $created_date;
    }

   
}