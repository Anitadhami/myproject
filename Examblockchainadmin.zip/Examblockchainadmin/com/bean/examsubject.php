<?php
class examsubject{
    private $id;
    private $paper_id;
    private $exam_id;
    private $sub_name;
    private $exam_date;
    private $created_by;
    private $created_date;
    /**
     * @param mixed $sub_name
     */
    public function setSub_name($sub_name)
    {
        $this->sub_name = $sub_name;
    }

    /**
     * @return mixed
     */
    public function getPaper_id()
    {
        return $this->paper_id;
    }

    /**
     * @return mixed
     */
    public function getExam_id()
    {
        return $this->exam_id;
    }

    /**
     * @return mixed
     */
    public function getSub_name()
    {
        return $this->sub_name;
    }

    /**
     * @return mixed
     */
    public function getExam_date()
    {
        return $this->exam_date;
    }

    /**
     * @return mixed
     */
    public function getCreated_by()
    {
        return $this->created_by;
    }

    /**
     * @return mixed
     */
    public function getCreated_date()
    {
        return $this->created_date;
    }

    /**
     * @param mixed $paper_id
     */
    public function setPaper_id($paper_id)
    {
        $this->paper_id = $paper_id;
    }

    /**
     * @param mixed $exam_id
     */
    public function setExam_id($exam_id)
    {
        $this->exam_id = $exam_id;
    }

    /**
     * @param mixed $subject_name
     */
    public function setSubject_name($subject_name)
    {
        $this->subject_name = $subject_name;
    }

    /**
     * @param mixed $exam_date
     */
    public function setExam_date($exam_date)
    {
        $this->exam_date = $exam_date;
    }

    /**
     * @param mixed $created_by
     */
    public function setCreated_by($created_by)
    {
        $this->created_by = $created_by;
    }

    /**
     * @param mixed $created_date
     */
    public function setCreated_date($created_date)
    {
        $this->created_date = $created_date;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getPaperid()
    {
        return $this->paperid;
    }

    /**
     * @return mixed
     */
    public function getExamid()
    {
        return $this->examid;
    }

    /**
     * @return mixed
     */
    public function getSubjectname()
    {
        return $this->subjectname;
    }

    /**
     * @return mixed
     */
    public function getExamdate()
    {
        return $this->examdate;
    }

    /**
     * @return mixed
     */
    public function getCreatedby()
    {
        return $this->createdby;
    }

    /**
     * @return mixed
     */
    public function getCreateddate()
    {
        return $this->createddate;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $paperid
     */
    public function setPaperid($paperid)
    {
        $this->paperid = $paperid;
    }

    /**
     * @param mixed $examid
     */
    public function setExamid($examid)
    {
        $this->examid = $examid;
    }

    /**
     * @param mixed $subjectname
     */
    public function setSubjectname($subjectname)
    {
        $this->subjectname = $subjectname;
    }

    /**
     * @param mixed $examdate
     */
    public function setExamdate($examdate)
    {
        $this->examdate = $examdate;
    }

    /**
     * @param mixed $createdby
     */
    public function setCreatedby($createdby)
    {
        $this->createdby = $createdby;
    }

    /**
     * @param mixed $createddate
     */
    public function setCreateddate($createddate)
    {
        $this->createddate = $createddate;
    }

}