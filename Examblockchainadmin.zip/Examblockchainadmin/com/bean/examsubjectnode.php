<?php
class examsubjectnode{
    private $id;
    private $exam_id;
    private $sub_id;
    private $node_id;
    private $created_by;
    private $created_date;
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getExam_id()
    {
        return $this->exam_id;
    }

    /**
     * @return mixed
     */
    public function getSub_id()
    {
        return $this->sub_id;
    }

    /**
     * @return mixed
     */
    public function getNode_id()
    {
        return $this->node_id;
    }

    /**
     * @return mixed
     */
    public function getCreated_by()
    {
        return $this->created_by;
    }

    /**
     * @return mixed
     */
    public function getCreated_date()
    {
        return $this->created_date;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $exam_id
     */
    public function setExam_id($exam_id)
    {
        $this->exam_id = $exam_id;
    }

    /**
     * @param mixed $sub_id
     */
    public function setSub_id($sub_id)
    {
        $this->sub_id = $sub_id;
    }

    /**
     * @param mixed $node_id
     */
    public function setNode_id($node_id)
    {
        $this->node_id = $node_id;
    }

    /**
     * @param mixed $created_by
     */
    public function setCreated_by($created_by)
    {
        $this->created_by = $created_by;
    }

    /**
     * @param mixed $created_date
     */
    public function setCreated_date($created_date)
    {
        $this->created_date = $created_date;
    }

}