<?php
class nodesecuritykey{
    private $id;
    private $keyid;
    private $nodeid;
    private $algorithm;
    private $key_type;
    private $key_value;
    private $type;
    private $subtype;
    private $createdby;
    private $createddate;
    private $updatedby;
    private $updateddate;
    /**
     * @return mixed
     */
    public function getKey_type()
    {
        return $this->key_type;
    }

    /**
     * @param mixed $key_type
     */
    public function setKey_type($key_type)
    {
        $this->key_type = $key_type;
    }

    /**
     * @return mixed
     */
    public function getUpdatedby()
    {
        return $this->updatedby;
    }

    /**
     * @return mixed
     */
    public function getUpdateddate()
    {
        return $this->updateddate;
    }

    /**
     * @param mixed $updatedby
     */
    public function setUpdatedby($updatedby)
    {
        $this->updatedby = $updatedby;
    }

    /**
     * @param mixed $updateddate
     */
    public function setUpdateddate($updateddate)
    {
        $this->updateddate = $updateddate;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getKeyid()
    {
        return $this->keyid;
    }

    /**
     * @return mixed
     */
    public function getNodeid()
    {
        return $this->nodeid;
    }

    /**
     * @return mixed
     */
    public function getAlgorithm()
    {
        return $this->algorithm;
    }

    /**
     * @return mixed
     */
    public function getKey__type()
    {
        return $this->key__type;
    }

    /**
     * @return mixed
     */
    public function getKey_value()
    {
        return $this->key_value;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @return mixed
     */
    public function getSubtype()
    {
        return $this->subtype;
    }

    /**
     * @return mixed
     */
    public function getCreatedby()
    {
        return $this->createdby;
    }

    /**
     * @return mixed
     */
    public function getCreateddate()
    {
        return $this->createddate;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $keyid
     */
    public function setKeyid($keyid)
    {
        $this->keyid = $keyid;
    }

    /**
     * @param mixed $nodeid
     */
    public function setNodeid($nodeid)
    {
        $this->nodeid = $nodeid;
    }

    /**
     * @param mixed $algorithm
     */
    public function setAlgorithm($algorithm)
    {
        $this->algorithm = $algorithm;
    }

    /**
     * @param mixed $key__type
     */
    public function setKey__type($key__type)
    {
        $this->key__type = $key__type;
    }

    /**
     * @param mixed $key_value
     */
    public function setKey_value($key_value)
    {
        $this->key_value = $key_value;
    }

    /**
     * @param mixed $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }

    /**
     * @param mixed $subtype
     */
    public function setSubtype($subtype)
    {
        $this->subtype = $subtype;
    }

    /**
     * @param mixed $createdby
     */
    public function setCreatedby($createdby)
    {
        $this->createdby = $createdby;
    }

    /**
     * @param mixed $createddate
     */
    public function setCreateddate($createddate)
    {
        $this->createddate = $createddate;
    }

    
}