<?php
class question{
    private $id;
    private $question_id;
    private $exam_id;
    private $subject_id;
    private $node_id;
    private $question;
    private $created_date;
   

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getQuestion_id()
    {
        return $this->question_id;
    }

    /**
     * @return mixed
     */
    public function getExam_id()
    {
        return $this->exam_id;
    }

    /**
     * @return mixed
     */
    public function getSubject_id()
    {
        return $this->subject_id;
    }

    /**
     * @return mixed
     */
    public function getNode_id()
    {
        return $this->node_id;
    }

    /**
     * @return mixed
     */
    public function getQuestion()
    {
        return $this->question;
    }

    /**
     * @return mixed
     */
    public function getCreated_date()
    {
        return $this->created_date;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @param mixed $question_id
     */
    public function setQuestion_id($question_id)
    {
        $this->question_id = $question_id;
    }

    /**
     * @param mixed $exam_id
     */
    public function setExam_id($exam_id)
    {
        $this->exam_id = $exam_id;
    }

    /**
     * @param mixed $subject_id
     */
    public function setSubject_id($subject_id)
    {
        $this->subject_id = $subject_id;
    }

    /**
     * @param mixed $node_id
     */
    public function setNode_id($node_id)
    {
        $this->node_id = $node_id;
    }

    /**
     * @param mixed $question
     */
    public function setQuestion($question)
    {
        $this->question = $question;
    }

    /**
     * @param mixed $created_date
     */
    public function setCreated_date($created_date)
    {
        $this->created_date = $created_date;
    }

}