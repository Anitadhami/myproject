<?php
/*
 * Developer:- Suraj Mane
 * 
 * Date:- 8-7-2019
 * 
 * 
 */

class NodeController {
    public function addNode(){
	
	
		if ($_SERVER ['REQUEST_METHOD'] == 'POST') {
	
			$node = new Node();
			$lo = new Login();
			$node_dao = new nodeDaoImpl();
			//$node->setNode_id($_POST['node_id']);
			$node->setNode_name($_POST['node_name']);
			$node->setNode_ip_address($_POST['node_ip_address']);
			$node->setStatus($_POST['status']);
			$node->setCreated_by('ANITA');
			
			
   //code for login, node id use as a login id			
			//$lo->setEmail($_POST['email']);
			$lo->setPassword('apl#1234');
			$lo->setCreatedBy('ANITA');
			$lo->setUpdatedBy('ANITA');
	
			$result = $node_dao->addNode($node,$lo);
			echo json_encode ( $result );
	
	
		}
	}
	
	
	public function getNode()
	{
	    $node = new nodeDaoImpl();
	    $result = $node->getNode();
		return $result;
	}
}

?>