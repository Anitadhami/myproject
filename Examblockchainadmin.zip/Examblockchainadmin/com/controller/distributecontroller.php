
<?php
class distributecontroller{
    public function create_distribute(){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
            $n_array=null;
            $con = new Connection();
            $conn = $con->getConnection();
            $nd = array();
            $i = 0;
            $query = "SELECT * FROM `exam_subject_node` where exam_id=".$_POST['exam_id']." and sub_id=".$_POST['sub_id']."";
            $result = mysqli_query($conn, $query);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $node = new Node();
                    $node->setNode_id( $row ['node_id']);
                    $nd[$i ++] = array(
                        "id" => $row["node_id"],
                        "node" => $node
                    );
                
                    shuffle($nd);
                    $n_array = $nd[0];
                }
            }
            print_r($n_array);
            $dp= new distribute();
            $exsn = new distributeDaoImpl();
            
           // $dp->setDid($_POST['did']);
            $dp->setExam_id($_POST['exam_id']);
            $dp->setSubject_id($_POST['sub_id']);
            $dp->setNode_id($n_array["id"]);
            $dp->setCreated_by('ATOCONN');
            
            $result = $exsn->createdistribute($dp);
            echo json_encode( $result ) ;
            
        }
    }
    
    public function getdistribute()
    {
        $ds = new distributeDaoImpl();
        $result = $ds->getdistribute();
        return $result;
    }
    
    
}
?>