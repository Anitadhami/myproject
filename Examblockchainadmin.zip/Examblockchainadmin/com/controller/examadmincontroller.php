<?php
class examadmincontroller{
    public function createexamadmin($userid){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
            
            $con = new Connection();
            $conn = $con->getConnection();
            $key = 'bRuD5WYw5wd0rdHR9yLlM6wt2vteuiniQBqE70nAuhU=';  //accept this key with post method
            $eid = $this->getRowCount("exam_admin", $conn);
            $enc = $this->my_encrypt($eid."####".$_POST['exam_name']."####".$_POST['type'],$key);
            
            $ea= new examadmin();
            $b=new block();
            $exad = new examadminDaoImpl();
            
            $ea->setExam_name($_POST['exam_name']);
            $ea->setType($_POST['type']);
            $ea->setCreated_by('ANITA');
            
            $b->setBlock_id($userid."####".$eid);
            $b->setHash_of_blockid(md5($userid."####".$eid));//md5 used to apply hash on blockid
            $b->setId_of_previousblock(md5($eid."".$userid));
            $b->setHash_of_previousblock(md5($eid."@@@@".$userid));
            $b->setEncrypted_data($enc);
            $b->setHash_of_data(md5($eid."####".$_POST['exam_name']."####".$_POST['type']));
            $b->setRelated_db('exam_admin');
            
            
            
            $result = $exad->createexamadmin($ea,$b,$userid,$eid);
            echo json_encode( $result ) ;
            //return $result;
        }
    }
    
    public function getRowCount($tablename, $con)
    {
        $id = 0;
        $query = "SELECT count(`id`) as count FROM " . $tablename;
        $result = mysqli_query($con, $query);
        
        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            if ($row = mysqli_fetch_assoc($result)) {
                $id = $row["count"];
                $id = $id + 1;
            }
        }
        return $id;
    }
    
    public function getexamadmin()
    {
        $ea = new examadminDaoImpl();
        $result = $ea->getexamadmin();
        return $result;
    }
    
    
    
    public function getblock()
    {
        $bl = new examadminDaoImpl();
        $result = $bl->getblock();
        return $result;
    }
    
    
    public function my_encrypt($data, $key) {
        // Remove the base64 encoding from our key
        $encryption_key = base64_decode($key);
        // Generate an initialization vector
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        // Encrypt the data using AES 256 encryption in CBC mode using our encryption key and initialization vector.
        $encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
        // The $iv is just as important as the key for decrypting, so save it with our encrypted data using a unique separator (::)
        return base64_encode($encrypted . '::' . $iv);
    }
    
    public function my_decrypt($data, $key) {
        // Remove the base64 encoding from our key
        $encryption_key = base64_decode($key);
        // To decrypt, split the encrypted data from our IV - our unique separator used was "::"
        list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
        return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
    }
}
?>