<?php
class examsubjectcontroller{
    public function createexamsubject($userid){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
          
            $key = 'bRuD5WYw5wd0rdHR9yLlM6wt2vteuiniQBqE70nAuhU=';  //accept this key with post method
            $con = new Connection();
            $conn = $con->getConnection();
            $sid = $this->getRowCount("exam_subject", $conn);
            $enc = $this->my_encrypt($sid."####".$_POST['exam_id']."####".$_POST['sub_name']."####".$_POST['exam_date'],$key);
            
            $sb= new examsubject();
            $b=new block();
            $esb = new examsubjectDaoImpl();
            
            $sb->setExam_id($_POST['exam_id']);
            $sb->setSub_name($_POST['sub_name']);
            $sb->setExam_date($_POST['exam_date']);
            $sb->setCreated_by('ANITA');
                        
            
            $b->setBlock_id($userid."####".$sid."####".$_POST['exam_id']);
            $b->setHash_of_blockid(md5($userid."####".$sid."####".$_POST['exam_id']));//md5 used to apply hash on blockid            
            $b->setEncrypted_data($enc);
            $b->setId_of_previousblock(md5($userid."".$sid."".$_POST['exam_id']));
            $b->setHash_of_previousblock(md5($userid."@@@@".$sid."@@@@".$_POST['exam_id']));
            $b->setHash_of_data(md5($sid."####".$_POST['exam_id']."####".$_POST['sub_name']."####".$_POST['exam_date']));
            $b->setRelated_db('exam_subject');
            
            
            $result = $esb->createexamsubject($sb,$b,$userid,$sid);
            echo json_encode( $result ) ;
            //return $result;
            
        }
    }
    
    public function my_encrypt($data, $key) {
        // Remove the base64 encoding from our key
        $encryption_key = base64_decode($key);
        // Generate an initialization vector
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        // Encrypt the data using AES 256 encryption in CBC mode using our encryption key and initialization vector.
        $encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
        // The $iv is just as important as the key for decrypting, so save it with our encrypted data using a unique separator (::)
        return base64_encode($encrypted . '::' . $iv);
    }
    
    public function my_decrypt($data, $key) {
        // Remove the base64 encoding from our key
        $encryption_key = base64_decode($key);
        // To decrypt, split the encrypted data from our IV - our unique separator used was "::"
        list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
        return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
    }
    public function getRowCount($tablename, $con)
    {
        
        
        $id = 0;
        $query = "SELECT count(`id`) as count FROM " . $tablename;
        $result = mysqli_query($con, $query);
        
        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            if ($row = mysqli_fetch_assoc($result)) {
                $id = $row["count"];
                $id = $id + 1;
            }
        }
        return $id;
    }
    public function getexamsubject()
    {
        $sb = new examsubjectDaoImpl();
        $result = $sb->getexamsubject();
        return $result;
    }
}


?>

