<?php
class examsubjectnodecontroller{
    public function createexamsubjectnode(){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
            
            
            $esn= new examsubjectnode();
            $exsn = new examsubjectnodeDaoImpl();
            
            $esn->setExam_id($_POST['exam_id']);
            $esn->setSub_id($_POST['sub_id']);
            $esn->setNode_id($_POST['node_id']);
            $esn->setCreated_by('ANITA');
            
            $result = $exsn->createexamsubjectnode($esn);
            echo json_encode( $result ) ;
            
        }
    }
    
    public function getexamsubjectnode()
    {
        $esn = new examsubjectnodeDaoImpl();
        $result = $esn->getexamsujectnode();
        return $result;
    }
}
?>