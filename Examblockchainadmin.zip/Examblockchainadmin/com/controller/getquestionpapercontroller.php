
<?php
class getquestionpapercontroller{
    public function getquestionpaper(){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
            $nd=null;
            $con = new Connection();
            $conn = $con->getConnection();
           
            $query = "SELECT * FROM `distribute` where exam_id=".$_POST['exam_id']." and subject_id=".$_POST['sub_id']."";
            //echo $query;
            $result = mysqli_query($conn, $query);
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    //$node = new Node();
                    $d = new distribute();
                    $d->setNode_id( $row ['node_id']);
                    
                    $nd = $row ['node_id'];
                   
                }
            }
            //echo $nd;
            $dp= new distribute();
            $getpaper = new getquestionpaperDaoImpl();
            
           // $dp->setDid($_POST['did']);
            $dp->setExam_id($_POST['exam_id']);
            $dp->setSubject_id($_POST['sub_id']);
            $dp->setNode_id($nd);
            
            $result = $getpaper->getquestionpaper($dp);
            echo json_encode( $result ) ;
            
        }
    }
//     public function getexamadmin()
//     {
        
//         $ea = new examadminDaoImpl();
//         $result = $ea->getexamadmin();
//         return $result;
//     }
    
    
}
?>