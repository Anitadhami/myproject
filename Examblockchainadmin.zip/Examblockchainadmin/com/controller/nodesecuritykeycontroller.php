<?php
class nodesecuritykeyController{
    public function createnodesecuritykey(){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
            
            
            $nsk= new Nodesecuritykey();
            $nskc = new nodesecuritykeyDaoImpl();
            
            
           //nsk->setId($_POST['id']);
            $nsk->setKeyid($_POST['keyid']);
            $nsk->setNodeid($_POST['nodeid']);
            $nsk->setAlgorithm($_POST['algorithm']);
            $nsk->setKey_type($_POST['key_type']);
            $nsk->setKey_value($_POST['key_value']);
            $nsk->setType('security');
            $nsk->setSubtype('AES');
            $nsk->setCreatedBy('ATOCONN');
            $nsk->setUpdatedBy('ATOCONN');
            
            $result = $nskc->createnodesecuritykey($nsk);
            echo json_encode( $result ) ;
            
        }
    }
    
    public function getnodesecuritykey()
    {
        $nsk = new nodesecuritykeyDaoImpl();
        $result = $nsk->getnodesecuritykey();
        return $result;
    }
}
?>