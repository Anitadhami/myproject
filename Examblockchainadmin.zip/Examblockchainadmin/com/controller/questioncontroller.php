
<?php
class questioncontroller{
    
    public function createquestion($userid){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
            
            $con = new Connection();
            $conn = $con->getConnection();
            $qid = $this->getRowCount("question", $conn);
            $q= new question();
            $b=new block();
            $qu = new questionDaoImpl();
           echo $userid;
 
            $q->setExam_id($_POST['exam_id']);
            $q->setSubject_id($_POST['subject_id']);
            $q->setQuestion($_POST['question'] );
            $q->setNode_id($_POST['node_id']);
              
            
            $b->setBlock_id($userid."#".$qid);
            $b->setHash_of_blockid(md5($userid."#".$qid));//md5 used to apply hash on blockid
            $b->setHash_of_data(md5($qid."".$_POST['exam_id']."".$_POST['subject_id']."".$_POST['node_id']."".$_POST['question']));
            
           
            $result = $qu->createquestion($q,$b,$userid,$qid);
            echo json_encode( $result ) ;
            
        }
    }
    
    
    public function getRowCount($tablename, $con)
    {
        $id = 0;
        $query = "SELECT count(`id`) as count FROM " . $tablename;
        $result = mysqli_query($con, $query);
        
        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            if ($row = mysqli_fetch_assoc($result)) {
                $id = $row["count"];
                $id = $id + 1;
            }
        }
        return $id;
    }
    
    public function getquestion()
    {
        $e = new questionDaoImpl();
        $result = $e->getquestion();
        return $result;
    }
    
    public function create_question()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $b = new block();
            $question = new questionDaoImpl();
            
            $b->setBlock_id($_POST['block_id']);
            $b->setHash_of_blockid($_POST['hash_of_blockid']);
            $b->setId_of_previousblock($_POST['id_of_previousblock']);
            $b->setHash_of_previousblock($_POST['hash_of_previousblock']);
            $b->setEncrypted_data($_POST['encrypted_data']);
            $b->setHash_of_data($_POST['hash_of_data']);
            $b->setRelated_db($_POST['related_db']);
            $b->setRelated_node($_POST['related_node']);
            $b->setRelated_id($_POST['related_id']);
            
            $result = $question->create_question($b);
            echo json_encode($result);
        }
    }
}
?>