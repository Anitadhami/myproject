
<?php
class studentcontroller{
    public function create_student(){
        if ($_SERVER ['REQUEST_METHOD'] == 'POST'){
            
            $key = 'bRuD5WYw5wd0rdHR9yLlM6wt2vteuiniQBqE70nAuhU=';
            $con = new Connection();
            $conn = $con->getConnection();
            $s= new student();
            $b= new block();
            $sid = $this->getRowCount("student_reg", $conn);
            //echo $userid;
            $enc = $this->my_encrypt($sid."####".$_POST['sname']."####".$_POST['phone_no']."####".$_POST['email_id']."####".$_POST['dob']."####".$_POST['qualification']."####".$_POST['branch']."####".$_POST['class']."####".$_POST['address'], $key);
            
            $exsn = new studentDaoImpl();
            
           // $dp->setDid($_POST['did']);
            $s->setSname($_POST['sname']);
            $s->setPhone_no($_POST['phone_no']);
            $s->setEmail_id($_POST['email_id']);
            $s->setDob($_POST['dob']);
            $s->setQualification($_POST['qualification']);
            $s->setBranch($_POST['branch']);
            $s->setClass($_POST['class']);
            $s->setAddress($_POST['address']);
            $s->setCreated_by('ATOCONN');
            
            // Accepting block values
            
            $b->setBlock_id($sid."##".$_POST['node_id']);
            $b->setHash_of_blockid(md5($sid."##".$_POST['node_id']));//md5 used to apply hash on blockid
            $b->setId_of_previousblock(md5($sid."".$_POST['node_id']));
            $b->setHash_of_previousblock(md5($sid."@@@@".$_POST['node_id']));
            $b->setEncrypted_data($enc);
            $b->setHash_of_data(md5($enc));
            $b->setRelated_db('student_reg');
            $b->setRelated_node($_POST['node_id']);
            
            $result = $exsn->create_Student($s,$b,$sid);
            echo json_encode( $result ) ;
            
        }
    }
    
   
    
    
    public function my_encrypt($data, $key)
    {
        // Remove the base64 encoding from our key
        $encryption_key = base64_decode($key);
        // Generate an initialization vector
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        // Encrypt the data using AES 256 encryption in CBC mode using our encryption key and initialization vector.
        $encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
        // The $iv is just as important as the key for decrypting, so save it with our encrypted data using a unique separator (::)
        return base64_encode($encrypted . '::' . $iv);
    }
    
    public function my_decrypt($data, $key)
    {
        // Remove the base64 encoding from our key
        $encryption_key = base64_decode($key);
        // To decrypt, split the encrypted data from our IV - our unique separator used was "::"
        list ($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
        return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
    }
    public function getRowCount($tablename, $con)
    {
        $id = 0;
        $query = "SELECT count(`id`) as count FROM " . $tablename;
        $result = mysqli_query($con, $query);
        
        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            if ($row = mysqli_fetch_assoc($result)) {
                $id = $row["count"];
                $id = $id + 1;
            }
        }
        return $id;
    }
    
    public function createstudent()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $b = new block();
            $student = new studentDaoImpl();
            
            $b->setBlock_id($_POST['block_id']);
            $b->setHash_of_blockid($_POST['hash_of_blockid']);
            $b->setId_of_previousblock($_POST['id_of_previousblock']);
            $b->setHash_of_previousblock($_POST['hash_of_previousblock']);
            $b->setEncrypted_data($_POST['encrypted_data']);
            $b->setHash_of_data($_POST['hash_of_data']);
            $b->setRelated_db($_POST['related_db']);
            $b->setRelated_node($_POST['related_node']);
            $b->setRelated_id($_POST['related_id']);
            
            $result = $student->createstudent($b);
            echo json_encode($result);
        }
    }
    
    public function getStudent()
    {
        $s = new studentDaoImpl();
        $result = $s->getStudent();
        return $result;
    }
    
    public function getblockStudentId($sid)
    {
        $s = new studentDaoImpl();
        $result = $s->getblockStudentId($sid);
        return $result;
    }
    
    public function getblock()
    {
        $bl = new questionDaoImpl();
        $result = $bl->getblock();
        return $result;
    }
    
    public function getblockById($sid)
    {
        $bl = new questionDaoImpl();
        $result = $bl->getblockById($sid);
        return $result;
    }
    
    public function getnodeIP($userid,$sid)
    {
        $bl = new studentDaoImpl();
        $result = $bl->getnodeIP($userid,$sid);
        return $result;
    }
    
    public function addCertificate()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            
            $b = new block();
            $student = new studentDaoImpl();
            
            $b->setBlock_id($_POST['block_id']);
            $b->setHash_of_blockid($_POST['hash_of_blockid']);
            $b->setId_of_previousblock($_POST['id_of_previousblock']);
            $b->setHash_of_previousblock($_POST['hash_of_previousblock']);
            $b->setEncrypted_data($_POST['encrypted_data']);
            $b->setHash_of_data($_POST['hash_of_data']);
            $b->setRelated_db($_POST['related_db']);
            $b->setRelated_node($_POST['related_node']);
            $b->setRelated_id($_POST['related_id']);
            
            $result = $student->addCertificate($b);
            echo json_encode($result);
        }
    }
}
?>