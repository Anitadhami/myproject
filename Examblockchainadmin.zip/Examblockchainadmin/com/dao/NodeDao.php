<?php
interface NodeDao{
    public function addNode($node,$lo);
	public function getNode();
}