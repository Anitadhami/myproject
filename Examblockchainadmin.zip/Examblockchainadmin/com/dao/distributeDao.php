<?php
interface distributeDao{
    public function createdistribute($dp);
    
}
?>