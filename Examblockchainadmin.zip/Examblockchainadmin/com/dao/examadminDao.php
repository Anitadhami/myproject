<?php
interface examadminDao{
    public function createexamadmin($ea,$b,$userid,$eid);
    
    public function getexamadmin();
}
?>