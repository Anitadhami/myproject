<?php
interface examsubjectDao{
    public function createexamsubject($sb,$b,$userid,$sid);
    
    public function getexamsubject();
}
?>