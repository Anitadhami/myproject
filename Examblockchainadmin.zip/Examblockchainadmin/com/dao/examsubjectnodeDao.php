
<?php
interface examsubjectnodeDao{
    public function createexamsubjectnode($esn);
    
    public function getexamsubjectnode();
}
?>