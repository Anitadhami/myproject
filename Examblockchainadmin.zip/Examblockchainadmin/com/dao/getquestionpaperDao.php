<?php
interface getquestionpaperDao{
    public function getquestionpaper($dp);
}
?>