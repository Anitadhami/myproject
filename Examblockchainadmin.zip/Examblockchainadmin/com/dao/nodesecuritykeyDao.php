<?php
interface nodesecuritykeyDao{
    public function createnodesecuritykey($nsk);
    
    public function getNodesecuritykey();
}
?>