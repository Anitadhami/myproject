<?php
interface studenteDao{
    public function create_Student($s,$b,$sid);
    
}
?>