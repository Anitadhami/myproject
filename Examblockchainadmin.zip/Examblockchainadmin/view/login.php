<?php
include '../com/auth/client_login.php';
include '../com/bean/Login.php';
?>