<?php
include '../com/auth/config.php';
include '../com/bean/Node.php';
include '../com/bean/Login.php';
include '../com/dao/NodeDao.php';
include '../com/dao/mysql/nodeDaoImpl.php';
include '../com/controller/NodeController.php';

$node = new NodeController();

$node->addNode();
?>